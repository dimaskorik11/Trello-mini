import { useState } from 'react';
import './App.css';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Main from './components/Main';
import { BoardContext } from './context/BoardContext';

function App() {
  const boardData = {
    active: 0,
    boards: [
      {
        name: 'Моя Борда',
        bgcolor: '#add8e6',
        list: [
          { id: "1", title: "Потрібно зробити", items: [{ id: "cdrFt", title: "Опис проекту 1" }] },
          { id: "2", title: "В процесі", items: [{ id: "cdrFv", title: "Опис проекту 2" }] },
          { id: "3", title: "Зроблено", items: [{ id: "cdrFb", title: "Опис проекту 3" }] }
        ]
      }
    ]
  };

  const [allboard, setAllBoard] = useState(boardData);

  const deleteItem = (listId, itemId) => {
    const updatedBoards = [...allboard.boards];
    const activeBoard = updatedBoards[allboard.active];
    const list = activeBoard.list.find((l) => l.id === listId);
    if (list) {
      list.items = list.items.filter((item) => item.id !== itemId);
      setAllBoard({ ...allboard, boards: updatedBoards });
    }
  };

  const deleteList = (listId) => {
    const updatedBoards = [...allboard.boards];
    const activeBoard = updatedBoards[allboard.active];
    activeBoard.list = activeBoard.list.filter((list) => list.id !== listId);
    setAllBoard({ ...allboard, boards: updatedBoards });
  };

  const editItem = (listId, itemId, newTitle) => {
    const updatedBoards = [...allboard.boards];
    const activeBoard = updatedBoards[allboard.active];
    const list = activeBoard.list.find((l) => l.id === listId);
    if (list) {
      const item = list.items.find((item) => item.id === itemId);
      if (item) {
        item.title = newTitle;
        setAllBoard({ ...allboard, boards: updatedBoards });
      }
    }
  };

  const editList = (listId, newTitle) => {
    const updatedBoards = [...allboard.boards];
    const activeBoard = updatedBoards[allboard.active];
    const list = activeBoard.list.find((l) => l.id === listId);
    if (list) {
      list.title = newTitle;
      setAllBoard({ ...allboard, boards: updatedBoards });
    }
  };

  return (
    <>
      <Header />
      <BoardContext.Provider value={{ allboard, setAllBoard, deleteItem, deleteList, editItem, editList }}>
        <div className="content flex">
          <Sidebar />
          <Main />
        </div>
      </BoardContext.Provider>
    </>
  );
}

export default App;
